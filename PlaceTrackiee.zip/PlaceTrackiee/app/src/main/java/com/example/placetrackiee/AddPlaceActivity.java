package com.example.placetrackiee;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class AddPlaceActivity extends AppCompatActivity {

    private EditText nameInput;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_place);

        // Initialize views and database helper
        nameInput = findViewById(R.id.placeNameEditText);
        dbHelper = new DatabaseHelper(this);
    }

    public void addPlace(View view) {
        // Get the place name entered by the user
        String placeName = nameInput.getText().toString();

        // Validate place name
        if (placeName.isEmpty()) {
            Toast.makeText(this, "Please enter a place name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Use geocoding to obtain latitude and longitude for the entered place name
        Address address = getAddressForPlace(placeName);

        // Check if the address is valid and contains location information
        if (address != null) {
            double latitude = address.getLatitude();
            double longitude = address.getLongitude();

            // Save the place to the database
            long result = dbHelper.insertPlace(placeName, latitude, longitude);

            // Check if the place was successfully added
            if (result != -1) {
                Toast.makeText(this, "Place added successfully", Toast.LENGTH_SHORT).show();
                // Go back to the main activity
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to add place", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Failed to get location for the place", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to get latitude and longitude for the entered place name using geocoding
    private Address getAddressForPlace(String placeName) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocationName(placeName, 1);
            if (addresses != null && !addresses.isEmpty()) {
                return addresses.get(0); // Return the first address found
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Return null if no address found or an error occurred
    }
}
